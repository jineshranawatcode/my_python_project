def main():
    print("Hello from Jenkins CI/CD Pipeline!")

if __name__ == "__main__":
    main()
